# Auction-Marketer-Tech-Test
Technical test for a front end role.
